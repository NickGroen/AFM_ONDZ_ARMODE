Voor het maken van een AFM AR beeld is het volgende nodig:

- bestand "AFM_test29.obj"
- een app dat in staat is .obj te openen in AR. Deze komen veel voor, toch raadt ik aan "i4 AUGMENTED REVIEW". Link naar app:https://play.google.com/store/apps/details?id=de.cadschroer.aruniload.simple

De app zelf is leeg op een paar voorbeelden na. Om te beginnen met de bezichtiging in AR,  selecteer "AFM_test29.obj". Richt de telefoon op een oppervlak, het zal automatisch het oppervlak zoeken en in kaart brengen.
Wanneer het oppervlak in kaart is gebracht verschijnt een rood raster in het scherm. Door te tikken op het raster kan het model van de AFM worden geplaatst.